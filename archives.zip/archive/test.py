print("Marie je t'aime")
print("Marie c'est mon amoureuse")
